
#pragma once

#include <vector>
#include <algorithm>
#include <ClanLib/core.h>
#include <ClanLib/display.h>
#include <ClanLib/gl.h>
#include <ClanLib/gui.h>
#include <ClanLib/sound.h>
#include <ClanLib/vorbis.h>
#include <ClanLib/network.h>
#include <ClanLib/database.h>
#include <ClanLib/sqlite.h>
#include <ClanLib/csslayout.h>
#define FORIN(_type, _it, _vector) for(_type::iterator _it = _vector.begin(); _it != _vector.end(); _it++)
#define FORIN2(_type, _it, _vector, _beginit) for(_type::iterator _it = _beginit; _it != _vector.end(); _it++)
#define ITEMIN(_item, _vector) (std::find(_vector.begin(), _vector.end(), _item) != _vector.end())
#define KEYINMAP(_key, _map) (_map.find(_key) != _map.end())
