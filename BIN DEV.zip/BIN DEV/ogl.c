/*
   It kind of has to be a 16 bit computer.

ADD/SUB/MUL/DIV, trigonometry, null ops, dot cross normalize, bitwise, if else, pointer operation  
integer, float, double, string, binary, hexa, NaN
font rendering, 3d polygon filling, shaders, textures, path tracing, gui, console  


We need to render using font rendering tech to render ASCII ART MOVIE to show off
AT LIST 1024x768
INPUT format TTF, ASCII TXT FILE -> ASCII ART MOVIE

Need freetype2 font source code
 */
#include <X11/Xlib.h>                                                              
#include <X11/Xatom.h>                                                             
#include <X11/keysym.h>                                                                   
#include <stdio.h>
#include <string.h>
#include <X11/extensions/xf86vmode.h>                                             
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glx.h>                                                                
#include <GL/glu.h>                                                              
#include "ogl.h"

#define TITLE "Software Multi-Core CPU using GPU"

typedef unsigned char uchar;
typedef unsigned char bool;
#define false 0
#define true 1

double SW = 512.0; // Screen Width
double SH = 512.0; // Height
GLuint texture[7]; // General Textures
GLuint negatore; // Negation Texture
GLubyte image[7][512*512*4]; // General Texture Memory 1
GLubyte negation[512*512*4]; // Negation Texture Memory
GLubyte result[512*512*4]; // Result Texture Memory
GLuint fb, color_tex; // Frame Buffer Object
GLuint sp; // shader program

void printLog(GLuint obj) // Print Shader Logs
{
	int infologLength = 0;
	int maxLength;

	if(glIsShader(obj))
		glGetShaderiv(obj,GL_INFO_LOG_LENGTH,&maxLength);
	else
		glGetProgramiv(obj,GL_INFO_LOG_LENGTH,&maxLength);

	char infoLog[maxLength];

	if (glIsShader(obj))
		glGetShaderInfoLog(obj, maxLength, &infologLength, infoLog);
	else
		glGetProgramInfoLog(obj, maxLength, &infologLength, infoLog);

	if (infologLength > 0)
		printf("%s\n",infoLog);
}
char *file2string(const char *path) // Load Shader File And Convert It Into string
{
	FILE *fd;
	long len,
	     r;
	char *str;

	if (!(fd = fopen(path, "r")))
	{
		fprintf(stderr, "Can't open file '%s' for reading\n", path);
		return NULL;
	}

	fseek(fd, 0, SEEK_END);
	len = ftell(fd);

	printf("File '%s' is %ld long\n", path, len);

	fseek(fd, 0, SEEK_SET);

	if (!(str = malloc(len * sizeof(char))))
	{
		fprintf(stderr, "Can't malloc space for '%s'\n", path);
		return NULL;
	}

	r = fread(str, sizeof(char), len, fd);

	str[r - 1] = '\0'; /* Shader sources have to term with null */

	fclose(fd);

	return str;
}

typedef struct {
	Display *dpy;
	int screen;  
	Window win;  
	GLXContext ctx;
	XSetWindowAttributes attr;
	Bool fs;                  
	Bool doubleBuffered;      
	XF86VidModeModeInfo deskMode;
	int x, y;                    
	unsigned int width, height;  
	unsigned int depth;                                                                                                                                        
} GLWindow;                                                                                                                                                    

GLWindow GLWin;                                                                                                                                                

/* most important variable
 * it contains information about the X server which we communicate with
 */                                                                    
Display               * display;                                       
int                     screen;                                        
/* our window instance */                                              
Window                  window;                                        
GLXContext              context;                                       
XSetWindowAttributes    winAttr;                                       
Bool                    fullscreen = False;                            
Bool                    doubleBuffered;                                
/* original desktop mode which we save so we can restore it later */   
XF86VidModeModeInfo     desktopMode;                                   
int                     x, y;                                          
unsigned int            width, height;                                 
unsigned int            depth;                                         

GLfloat                 rotQuad = 0.0f;

/* attributes for a single buffered visual in RGBA format with at least
 * 4 bits per color and a 16 bit depth buffer */                       
static int attrListSgl[] =                                             
{                                                                      
	GLX_RGBA, GLX_RED_SIZE, 4,                                         
	GLX_GREEN_SIZE, 4,                                                 
	GLX_BLUE_SIZE, 4,                                                  
	GLX_DEPTH_SIZE, 16,                                                
	None                                                               
};                                                                     

/* attributes for a double buffered visual in RGBA format with at least
 * 4 bits per color and a 16 bit depth buffer */                       
static int attrListDbl[] =                                             
{                                                                      
	GLX_RGBA, GLX_DOUBLEBUFFER,                                        
	GLX_RED_SIZE, 4,                                                   
	GLX_GREEN_SIZE, 4,                                                 
	GLX_BLUE_SIZE, 4,                                                  
	GLX_DEPTH_SIZE, 16,                                                
	None                                                               
};                                                                     

/*
 * create a window
 */               
void createWindow()
{                  
	XVisualInfo *vi;
	Colormap cmap;  
	int i, dpyWidth, dpyHeight;
	int glxMajor, glxMinor, vmMajor, vmMinor;
	XF86VidModeModeInfo **modes;             
	int modeNum, bestMode;                   
	Atom wmDelete;                           
	Window winDummy;                         
	unsigned int borderDummy;                

	/* set best mode to current */
	bestMode = 0;                 
	/* get a connection */        
	display = XOpenDisplay(0);    
	screen = DefaultScreen(display);
	XF86VidModeQueryVersion(display, &vmMajor, &vmMinor);
	printf("XF86 VideoMode extension version %d.%d\n", vmMajor, vmMinor);
	XF86VidModeGetAllModeLines(display, screen, &modeNum, &modes);       
	/* save desktop-resolution before switching modes */                 
	GLWin.deskMode = *modes[0];
	desktopMode = *modes[0];                                      
	/* look for mode with requested resolution */                        
	for (i = 0; i < modeNum; i++)                                        
	{                                                                    
		if ((modes[i]->hdisplay == width) && (modes[i]->vdisplay == height))
			bestMode = i;                                                   
	}                                                                       
	/* get an appropriate visual */                                         
	vi = glXChooseVisual(display, screen, attrListDbl);                     
	if (vi == NULL)                                                         
	{                                                                       
		vi = glXChooseVisual(display, screen, attrListSgl);                 
		doubleBuffered = False;                                             
		printf("singlebuffered rendering will be used, no doublebuffering available\n");
	}                                                                                   
	else                                                                                
	{                                                                                   
		doubleBuffered = True;                                                          
		printf("doublebuffered rendering available\n");                                 
	}                                                                                   
	glXQueryVersion(display, &glxMajor, &glxMinor);                                     
	printf("GLX-Version %d.%d\n", glxMajor, glxMinor);                                  
	/* create a GLX context */                                                          
	context = glXCreateContext(display, vi, 0, GL_TRUE);                                
	/* create a color map */                                                            
	cmap = XCreateColormap(display, RootWindow(display, vi->screen),                    
			vi->visual, AllocNone);                                                         
	winAttr.colormap = cmap;                                                            
	winAttr.border_pixel = 0;                                                           

	if (fullscreen)
	{              
		/* switch to fullscreen */
		XF86VidModeSwitchToMode(display, screen, modes[bestMode]);
		XF86VidModeSetViewPort(display, screen, 0, 0);            
		dpyWidth = modes[bestMode]->hdisplay;                     
		dpyHeight = modes[bestMode]->vdisplay;                    
		printf("resolution %dx%d\n", dpyWidth, dpyHeight);        
		XFree(modes);                                             

		/* set window attributes */
		winAttr.override_redirect = True;
		winAttr.event_mask = ExposureMask | KeyPressMask | ButtonPressMask |
			StructureNotifyMask;                                            
		window = XCreateWindow(display, RootWindow(display, vi->screen),    
				0, 0, dpyWidth, dpyHeight, 0, vi->depth, InputOutput, vi->visual,
				CWBorderPixel | CWColormap | CWEventMask | CWOverrideRedirect,   
				&winAttr);                                                       
		XWarpPointer(display, None, window, 0, 0, 0, 0, 0, 0);               
		XMapRaised(display, window);                                 
		XGrabKeyboard(display, window, True, GrabModeAsync,                  
				GrabModeAsync, CurrentTime);                                     
		XGrabPointer(display, window, True, ButtonPressMask,                 
				GrabModeAsync, GrabModeAsync, window, None, CurrentTime);        
	}                                                                        
	else                                                                     
	{                                                                        
		/* create a window in window mode*/                                  
		winAttr.event_mask = ExposureMask | KeyPressMask | ButtonPressMask | 
			StructureNotifyMask;                                             
		window = XCreateWindow(display, RootWindow(display, vi->screen),     
				0, 0, width, height, 0, vi->depth, InputOutput, vi->visual,      
				CWBorderPixel | CWColormap | CWEventMask, &winAttr);             
		/* only set window title and handle wm_delete_events if in windowed mode */
		wmDelete = XInternAtom(display, "WM_DELETE_WINDOW", True);                 
		XSetWMProtocols(display, window, &wmDelete, 1);                            
		XSetStandardProperties(display, window, TITLE,                             
				TITLE, None, NULL, 0, NULL);                                           
		XMapRaised(display, window);                                               
	}                                                                              
	/* connect the glx-context to the window */                                    
	glXMakeCurrent(display, window, context);                                      
	if (glXIsDirect(display, context))                                             
		printf("DRI enabled\n");                                                   
	else                                                                           
		printf("no DRI available\n");                                              
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		/* Problem: glewInit failed, something is seriously wrong. */
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
	if (GLEW_VERSION_2_1)
	{
		fprintf(stderr, "OpenGL 2.1 works\n");
	}
	if (glewIsSupported("GL_ARB_framebuffer_object"))
	{
		fprintf(stderr, "Framebuffer Object Works\n");
	}
	if (glewIsSupported("GL_ARB_vertex_shader"))
	{
		fprintf(stderr, "Vertex Shader Works\n");
	}
	if (glewIsSupported("GL_ARB_fragment_shader"))
	{
		fprintf(stderr, "Fragment Shader Works\n");
	}
	GLuint tmu_num;
	glGetIntegerv (GL_MAX_TEXTURE_UNITS_ARB, &tmu_num);
	fprintf(stderr, "Maximum Num Texture Units: %d\n", tmu_num);
	initGL();                                                                      
}                                                                                  

/*
 * destroy the window
 */                  
void destroyWindow() 
{                    
	if( context )    
	{                
		if( !glXMakeCurrent(display, None, NULL))
		{                                        
			printf("Could not release drawing context.\n");
		}                                                  
		/* destroy the context */                          
		glXDestroyContext(display, context);               
		context = NULL;                                    
	}                                                      
	/* switch back to original desktop resolution if we were in fullscreen */
	if( fullscreen )                                                         
	{                                                                        
		XF86VidModeSwitchToMode(display, screen, &desktopMode);              
		XF86VidModeSetViewPort(display, screen, 0, 0);                       
	}                                                                        
	XCloseDisplay(display);                                                  
}                                                                            


void resizeGL(unsigned int width, unsigned int height)
{                                                     
	/* prevent divide-by-zero */                      
	if (height == 0)                                  
		height = 1;                                   
	glViewport(0, 0, width, height);                  
	glMatrixMode(GL_PROJECTION);                      
	glLoadIdentity();                                 
	glOrtho(0.0, SW, SH, 0.0, -30.0, 30.0);
	//gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);                                           
}                                                                         

void loadResources()
{
//네게이션
//7대게이트
//4Bit Full Adder
//NOR게이트와 NOT 게이트를 텍스쳐에 인코딩해두고 그걸 불러와서 7대게이트를 만든 후에
//7대 게이트를 마지막으로 텍스쳐에 인코딩해두고 그걸 불러와서 4Bit Full Adder를 만든다.
// Perfectosto Niholia Estus. Amen.
// if it's one neg
	memset(image, 0, sizeof(GLubyte)*512*512*4*7);
	memset(negation, 0, sizeof(GLubyte)*512*512*4);
	for(int y = 0; y < 512; ++y)
	{
		for(int x = 0; x < 512; ++x)
		{
			image[0][y*512*4 + x*4 + 0] = 255;
			image[0][y*512*4 + x*4 + 1] = 255;
			image[0][y*512*4 + x*4 + 2] = 255;
			image[0][y*512*4 + x*4 + 3] = 255;
			image[1][y*512*4 + x*4 + 0] = 255;
			image[1][y*512*4 + x*4 + 1] = 255;
			image[1][y*512*4 + x*4 + 2] = 255;
			image[1][y*512*4 + x*4 + 3] = 255;
			image[2][y*512*4 + x*4 + 0] = 0;
			image[2][y*512*4 + x*4 + 1] = 0;
			image[2][y*512*4 + x*4 + 2] = 0;
			image[2][y*512*4 + x*4 + 3] = 0;
			image[3][y*512*4 + x*4 + 0] = 255;
			image[3][y*512*4 + x*4 + 1] = 255;
			image[3][y*512*4 + x*4 + 2] = 255;
			image[3][y*512*4 + x*4 + 3] = 255;
		}
	}
	// 0, 0
	for(int y=0; y<3; ++y)
	{
		for(int x=0; x<3; ++x)
		{
			image[0][y*512*4 + x*4 + 0] = 0;
			image[0][y*512*4 + x*4 + 1] = 0;
			image[0][y*512*4 + x*4 + 2] = 0;
			image[0][y*512*4 + x*4 + 3] = 0;
			image[1][y*512*4 + x*4 + 0] = 0;
			image[1][y*512*4 + x*4 + 1] = 0;
			image[1][y*512*4 + x*4 + 2] = 0;
			image[1][y*512*4 + x*4 + 3] = 0;
		}
	}
	// 0, 1
	for(int y=0; y<3; ++y)
	{
		for(int x=3; x<6; ++x)
		{
			image[0][y*512*4 + x*4 + 0] = 0;
			image[0][y*512*4 + x*4 + 1] = 0;
			image[0][y*512*4 + x*4 + 2] = 0;
			image[0][y*512*4 + x*4 + 3] = 0;
			image[1][y*512*4 + x*4 + 0] = 255;
			image[1][y*512*4 + x*4 + 1] = 255;
			image[1][y*512*4 + x*4 + 2] = 255;
			image[1][y*512*4 + x*4 + 3] = 255;
		}
	}

	// 1, 0
	for(int y=0; y<3; ++y)
	{
		for(int x=6; x<9; ++x)
		{
			image[0][y*512*4 + x*4 + 0] = 255;
			image[0][y*512*4 + x*4 + 1] = 255;
			image[0][y*512*4 + x*4 + 2] = 255;
			image[0][y*512*4 + x*4 + 3] = 255;
			image[1][y*512*4 + x*4 + 0] = 0;
			image[1][y*512*4 + x*4 + 1] = 0;
			image[1][y*512*4 + x*4 + 2] = 0;
			image[1][y*512*4 + x*4 + 3] = 0;
		}
	}

	// 1, 1
	for(int y=0; y<3; ++y)
	{
		for(int x=9; x<12; ++x)
		{
			image[0][y*512*4 + x*4 + 0] = 255;
			image[0][y*512*4 + x*4 + 1] = 255;
			image[0][y*512*4 + x*4 + 2] = 255;
			image[0][y*512*4 + x*4 + 3] = 255;
			image[1][y*512*4 + x*4 + 0] = 255;
			image[1][y*512*4 + x*4 + 1] = 255;
			image[1][y*512*4 + x*4 + 2] = 255;
			image[1][y*512*4 + x*4 + 3] = 255;
		}
	}

	//fprintf(stderr, "%d, %d", 511*512*4+511*4+3, 512*512*4);
	glGenTextures(7, texture);
	for(int i=0; i<7; ++i)
	{
		glActiveTexture(GL_TEXTURE0+i);
		glBindTexture(GL_TEXTURE_2D, texture[i]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 512, 512, 0, GL_RGBA, GL_UNSIGNED_BYTE, image[i]);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST); // Linear Filtering
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST); // Linear Filtering
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	}

	// initialize color texture
	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &color_tex);
	glBindTexture(GL_TEXTURE_2D, color_tex);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, (int)SW, (int)SH, 0,
			GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST); // Linear Filtering
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST); // Linear Filtering
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	glGenFramebuffers(1, &fb);
	glBindFramebuffer(GL_FRAMEBUFFER, fb);
	glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER,
			GL_COLOR_ATTACHMENT0,
			GL_TEXTURE_2D, color_tex, 0);


	/* The vertex shader */
	char *vsSource = file2string("ogl.vert");
	char *fsSource = file2string("adder.frag");

	/* Compile and load the program */

	GLuint vs, /* Vertex Shader */
	       fs; /* Fragment Shader */


	vs = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vs, 1, (const GLchar**)&vsSource, NULL);
	glCompileShader(vs);
	printLog(vs);

	fs = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fs, 1, (const GLchar**)&fsSource, NULL);
	glCompileShader(fs);
	printLog(fs);

	free(vsSource);
	free(fsSource);

	sp = glCreateProgram();
	glAttachShader(sp, vs);
	glAttachShader(sp, fs);
	glLinkProgram(sp);
	printLog(sp);

	glUseProgram(sp);
	/*
	   GLfloat waveTime = 0.0,
	   waveWidth = 0.1,
	   waveHeight = 3.0,
	   waveFreq = 0.1;
	   GLint waveTimeLoc = glGetUniformLocation(sp, "waveTime");
	   GLint waveWidthLoc = glGetUniformLocation(sp, "waveWidth");
	   GLint waveHeightLoc = glGetUniformLocation(sp, "waveHeight");
	   printLog(sp);
	   glUniform1f(waveTimeLoc, waveTime);
	   glUniform1f(waveWidthLoc, waveWidth);
	   glUniform1f(waveHeightLoc, waveHeight);

	   glBegin(GL_QUADS);
	   for (i = -50; i < 50; i++)
	   for (j = -50; j < 50; j++)
	   {
	   glVertex2f(i, j);
	   glVertex2f(i + 1, j);
	   glVertex2f(i + 1, j + 1);
	   glVertex2f(i, j + 1);
	   }
	   glEnd();

	   waveTime += waveFreq;
	 */
}
void initGL()
{            
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);                  
	glEnable(GL_DEPTH_TEST);             
	glDepthFunc(GL_LEQUAL);              
	resizeGL(width, height);                                    
	rotQuad = 0;                                                
	glEnable(GL_TEXTURE_2D);
	loadResources();
	glFlush();                                                  

	//glGenRenderbuffers(1, &depth_rb);
	//glGenRenderbuffers(1, &stencil_rb);
}                                                               

void renderGL()
{              
	//fprintf(stderr, "asd");
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();                                  

	if(false)
	{
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
		glBegin(GL_QUADS);                                 
		glColor3f(0.0f, 1.0f, 1.0f);                   
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);                
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(SW, 0.0f, 0.0f);                 
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(SW, SH, 0.0f);                
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, SH, 0.0f);                
		glEnd();                                           
	}
	else
	{
		glUseProgram(sp);

		for(int i=0; i<7; ++i)
		{
			glActiveTexture(GL_TEXTURE0+i);
			glBindTexture(GL_TEXTURE_2D, texture[i]);
		}
		glUniform1i(glGetUniformLocation(sp, "color_texture"), 0);
		glUniform1i(glGetUniformLocation(sp, "color_texture1"), 1);
		glUniform1i(glGetUniformLocation(sp, "color_texture2"), 2);
		glUniform1i(glGetUniformLocation(sp, "color_texture3"), 3);
		glUniform1i(glGetUniformLocation(sp, "color_texture4"), 4);
		glUniform1i(glGetUniformLocation(sp, "color_texture5"), 5);
		glUniform1i(glGetUniformLocation(sp, "color_texture6"), 6);

		glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fb);
		glBegin(GL_QUADS);                                 
		glColor3f(0.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(SW, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(SW, SH, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, SH, 0.0f);
		glEnd();                                           



		glUseProgram(0);
		glActiveTexture(GL_TEXTURE7);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE3);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE4);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE5);
		glBindTexture(GL_TEXTURE_2D, 0);
		glActiveTexture(GL_TEXTURE6);
		glBindTexture(GL_TEXTURE_2D, 0);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, color_tex);
		glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
		glBegin(GL_QUADS);                                 
		glColor3f(0.0f, 1.0f, 1.0f);                   
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);                
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(SW, 0.0f, 0.0f);                 
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(SW, SH, 0.0f);                
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, SH, 0.0f);                
		glEnd();                                           
		glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid*)result);
	}


	if (doubleBuffered)                                
	{                                                  
		glXSwapBuffers(display, window);               
	}                                                  
}                                                      

int main(int argc, char ** argv)
{                               
	XEvent event;               
	Bool done = False;          

	width = SW;
	height = SH;

	createWindow();

	/* wait for events and eat up cpu. ;-) */
	while (!done)                            
	{                                        
		/* handle the events in the queue */ 
		while (XPending(display) > 0)        
		{                                    
			XNextEvent(display, &event);     
			switch (event.type)              
			{                                
				case Expose:                 
					if (event.xexpose.count != 0)
						break;                   
					fprintf(stderr, "OpenGL Context Lost. Reloading...\n");
					initGL(); // XXX: RELOAD
					renderGL();                      
					break;                       
				case ConfigureNotify:            
					/* call resizeGL only if our window-size changed */
					if ((event.xconfigure.width != GLWin.width) ||
							(event.xconfigure.height != GLWin.height))
					{
						width = event.xconfigure.width;
						height = event.xconfigure.height;
						resizeGL(width, height);
					}
					break;
					/* exit in case of a mouse button press */
				case ButtonPress:
					//done = True;
					break;
				case KeyPress:
					if (XLookupKeysym(&event.xkey, 0) == XK_Escape)
					{
						done = True;
					}
					break;
				case ClientMessage:
					if (strcmp(XGetAtomName(display, event.xclient.message_type),
								"WM_PROTOCOLS") == 0)
					{
						done = True;
					}
					break;
				default:
					break;
			}
		}
		renderGL();
	}

	destroyWindow();

	return 0;
}
