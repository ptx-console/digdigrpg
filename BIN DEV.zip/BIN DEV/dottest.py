# -*- coding: utf-8 -*-
def dot(a,b,c,d,a2,b2,c2,d2):
	return a*a2+b*b2+c*c2+d*d2
def cross(x,y,z, a,b,c):
	return (y*c-z*b, z*a-x*c, x*b-y*a)

# 2014-3-9 04:09:00 +0900
input = dot(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0)
result = dot(input,input,input,input,16.0,16.0,16.0,16.0) # and gate
print cross(result, 1.0, 1.0, 1.0, 1.0, 1.0)[1]
input = dot(0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0)
result = dot(input,input,input,input,16.0,16.0,16.0,16.0) # and gate
print cross(result, 1.0, 1.0, 1.0, 1.0, 1.0)[1]
input = dot(1.0,1.0,1.0,1.0,0.0,0.0,0.0,0.0)
result = dot(input,input,input,input,16.0,16.0,16.0,16.0) # and gate
print cross(result, 1.0, 1.0, 1.0, 1.0, 1.0)[1]
input = dot(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0)
result = dot(input,input,input,input,16.0,16.0,16.0,16.0) # and gate
print cross(result, 1.0, 1.0, 1.0, 1.0, 1.0)[1]

