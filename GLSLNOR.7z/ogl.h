#ifndef ogl_h_
#define ogl_h_ 1
void printLog(GLuint obj);
char *file2string(const char *path);
#endif
