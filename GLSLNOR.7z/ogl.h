#ifndef ogl_h_
#define ogl_h_ 1
void printLog(GLuint obj);
char *file2string(const char *path);
/* prototypes */
void createWindow();
void destroyWindow();
void resizeGL(unsigned int, unsigned int);
void initGL();                            
#endif
